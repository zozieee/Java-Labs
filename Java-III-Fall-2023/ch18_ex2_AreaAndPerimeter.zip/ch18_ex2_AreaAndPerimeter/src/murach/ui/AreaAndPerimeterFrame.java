/******************************************************************************
Programmer: Zoe Cope
Date: 11/01/2023
Lab 10
Instructor: Dr. Rafael Azuaje
College: San Antonio College

*******************************************************************************/
package murach.ui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.Dimension;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import murach.business.Rectangle;

public class AreaAndPerimeterFrame extends JFrame {

    private JTextField lenField;
    private JTextField widField;
    private JTextField areaField;
    private JTextField perimField;
    
    private JButton computeButton;
    private JButton resetButton;

    public AreaAndPerimeterFrame() {
        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException |
                 IllegalAccessException | UnsupportedLookAndFeelException e) {
            System.out.println(e);
        }
        initComponents();
    }

    private void initComponents() {
        setTitle("Area and Perimeter Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        
        // components 
        lenField = new JTextField();
        widField = new JTextField();
        areaField = new JTextField();
        perimField = new JTextField();
        
        //area and perimeter fields are not editable
        areaField.setEditable(false);
        perimField.setEditable(false);
        
        //set min. and pref. size of text fields
        Dimension dim = new Dimension(300, 20);
        lenField.setPreferredSize(dim);
        widField.setPreferredSize(dim);
        areaField.setPreferredSize(dim);
        perimField.setPreferredSize(dim);
        lenField.setMinimumSize(dim);
        widField.setMinimumSize(dim);
        areaField.setMinimumSize(dim);
        perimField.setMinimumSize(dim);
        
        computeButton = new JButton("Compute");
        resetButton = new JButton("Reset");
        
        computeButton.addActionListener(e->{computeButtonClicked(); });
        resetButton.addActionListener(e->{resetButtonClicked(); });
        
        //text panel
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.add(new JLabel("Length:"), 
                getConstraints(0,0));
        panel.add(lenField, 
                getConstraints(1,0));
        panel.add(new JLabel("Width:"), 
                getConstraints(0,1));
        panel.add(widField, 
                getConstraints(1,1));
        panel.add(new JLabel("Area:"), 
                getConstraints(0,2));
        panel.add(areaField, 
                getConstraints(1,2));
        panel.add(new JLabel("Perimeter:"), 
                getConstraints(0,3));
        panel.add(perimField, 
                getConstraints(1,3));
        add(panel, BorderLayout.CENTER);
        
        //button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(computeButton);
        buttonPanel.add(resetButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
        
        pack();
        setVisible(true);
    }

    // Helper method to return GridBagConstraints objects
    private GridBagConstraints getConstraints(int x, int y) {
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.LINE_START;
        c.insets = new Insets(5, 5, 0, 5);
        c.gridx = x;
        c.gridy = y;
        return c;
    }

    private void computeButtonClicked() {
        SwingValidator sv = new SwingValidator(this);
        if (sv.isDouble(lenField, "Length") && sv.isDouble(widField, "Width")){
            double len = Double.parseDouble(lenField.getText());
            double wid = Double.parseDouble(widField.getText());
            
            Rectangle r = new Rectangle(len, wid);
            areaField.setText(r.getAreaNumberFormat());
            perimField.setText(r.getPerimeterNumberFormat());
        } 
    }

    private void resetButtonClicked() {
        areaField.setText("");
        perimField.setText("");
        lenField.setText("");
        widField.setText("");
    }
    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            JFrame frame = new AreaAndPerimeterFrame();
        });        
    }
}